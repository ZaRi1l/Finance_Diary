import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class LicensePage2 extends StatefulWidget {
  var Lic;
  LicensePage2(this.Lic, {super.key});


  @override
  State<LicensePage2> createState() => _LicensePage2State(Lic);
}

class _LicensePage2State extends State<LicensePage2> {
  var Lic;

  _LicensePage2State(this.Lic);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("License"),
        backgroundColor: Colors.green[300],
        shadowColor: Colors.transparent,
      ),
      body: SingleChildScrollView(child: Text(Lic))
    );
  }
}