package com.example.finance_diary

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
