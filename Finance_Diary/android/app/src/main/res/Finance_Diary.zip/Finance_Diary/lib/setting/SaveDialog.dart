import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';


import 'package:top_snackbar_flutter/custom_snack_bar.dart';

import 'package:top_snackbar_flutter/top_snack_bar.dart';


import 'package:csv/csv.dart';

import '../data/diaryListData.dart';

class SaveDialog extends StatefulWidget {
  SaveDialog();

  @override
  State<SaveDialog> createState() => _SaveDialogState();
}

class _SaveDialogState extends State<SaveDialog> {
  ListAddData lad = ListAddData();


  @override
  Widget build(BuildContext context2) {
    final textFieldNum1 = TextEditingController(text: "투자 거래내역");


    return Scaffold(
      backgroundColor: Colors.transparent,
      body: AlertDialog(
        shadowColor: Colors.transparent,

        title: Container(
          decoration: ShapeDecoration(
              color: Colors.green[500],
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      topRight: Radius.circular(10)))),
          alignment: Alignment.centerLeft,
          height: 40,
          child: Row(
            children: [
              Padding(
                padding: EdgeInsets.only(left: 5, top: 2),
                child: Icon(Icons.save_outlined, color: Colors.white, size: 30),
              ),
              SizedBox(
                width: 3,
              ),
              Text(
                "저장",
                style: TextStyle(fontSize: 20, color: Colors.white),
              )
            ],
          ),
        ),
        titlePadding: const EdgeInsets.all(0),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        //------------------------^ 제목 꾸미기

        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("파일 경로"),
                  SizedBox(
                    width: 10,
                  ),
                  Flexible(child: Text("/storage/emulated/0/Download")),

                ],
              ),

              SizedBox(
                height: 10,
              ),


              Row(
                children: [
                  Text("파일 이름"),
                  SizedBox(
                    width: 10,
                  ),
                  Container(
                    width: 150,
                    height: 30,
                    child: TextField(
                      keyboardType: TextInputType.text,
                      controller: textFieldNum1,
                    ),
                  ),
                ],
              ),
              // --------------------^ 팝업메뉴 나중에 변수 추가해야함., 추가삭제 버튼도 만들기
            ],
          ),
        ),






        actions: [
          ElevatedButton(
            onPressed: () {
              var fname = textFieldNum1.text + ".csv";
              lad.csvSave(fname);
              Navigator.pop(context2);
            },

            child: Text("확인"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green[400], foregroundColor: Colors.white),
          ),

          ElevatedButton(
            onPressed: () {
              Navigator.pop(context2);
            },
            child: Text("취소"),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green[400], foregroundColor: Colors.white),
          )
        ],
      ),
    );
  }

}
